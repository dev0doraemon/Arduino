[![Travis Build Status](https://img.shields.io/travis/riuson/lcd-image-converter.svg?label=linux)](https://travis-ci.org/riuson/lcd-image-converter)
[![Coverity Scan](https://img.shields.io/coverity/scan/3997.svg?maxAge=2592000)](https://scan.coverity.com/projects/riuson-lcd-image-converter)

# LCD Image Converter
Tool to create bitmaps and fonts for embedded applications, v.2
This program allows you to create bitmaps and fonts, and transform them to "C"
source format for embedded applications.

## Author
 Vladimir riuson@gmail.com

## Web pages

- [Home Page] (http://www.riuson.com/lcd-image-converter)
- [GitHub] (https://github.com/riuson/lcd-image-converter)

##License

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/
